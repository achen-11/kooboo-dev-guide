import fs from 'fs-extra';
import path from 'path';
import chalk from 'chalk';
import ora from 'ora';
import { fileURLToPath } from 'url';

// 获取当前文件的目录
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// 模板目录
const templatesDir = path.resolve(__dirname, '../../templates');

/**
 * 创建项目
 * @param {string} projectName - 项目名称
 * @param {string} templateName - 模板名称
 */
export async function createProject(projectName, templateName) {
  const spinner = ora('正在创建项目...').start();
  
  try {
    // 项目目标路径
    const targetDir = path.resolve(process.cwd(), projectName);
    
    // 检查目标目录是否已存在
    if (fs.existsSync(targetDir)) {
      spinner.fail(chalk.red(`目录 ${projectName} 已存在，请选择其他名称或删除现有目录`));
      process.exit(1);
    }
    
    // 创建项目目录
    fs.mkdirSync(targetDir);
    
    // 创建基本目录结构
    const directories = [
      'views',
      'pages',
      'layouts',
      'scripts',
      'styles',
      'apis',
      'codeBlocks',
      'sync-json'
    ];
    
    for (const dir of directories) {
      fs.mkdirSync(path.join(targetDir, dir));
    }
    
    // 创建.gitignore文件
    fs.writeFileSync(
      path.join(targetDir, '.gitignore'),
      `node_modules/
.DS_Store
`
    );
    
    // 根据模板创建特定文件
    await createTemplateFiles(targetDir, templateName);
    
    spinner.succeed(chalk.green('项目目录结构创建成功'));
  } catch (error) {
    spinner.fail(chalk.red('创建项目失败'));
    console.error(error);
    process.exit(1);
  }
}

/**
 * 根据模板创建特定文件
 * @param {string} targetDir - 目标目录
 * @param {string} templateName - 模板名称
 */
async function createTemplateFiles(targetDir, templateName) {
  const templateDir = path.join(templatesDir, templateName);
  
  // 检查模板目录是否存在
  if (!fs.existsSync(templateDir)) {
    // 如果模板目录不存在，创建默认文件
    await createDefaultFiles(targetDir);
    return;
  }
  
  // 复制模板文件到目标目录
  await fs.copy(templateDir, targetDir, { overwrite: true });
}

/**
 * 创建默认文件
 * @param {string} targetDir - 目标目录
 */
async function createDefaultFiles(targetDir) {
  // 创建common.html
  fs.writeFileSync(
    path.join(targetDir, 'views', 'common.html'),
    `<!-- 公共引用 -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/element-plus@2.3.6/dist/index.css">

<script src="https://cdn.jsdelivr.net/npm/vue@3.2.47/dist/vue.global.js"></script>
<script src="https://cdn.jsdelivr.net/npm/vue-i18n@9.2.2/dist/vue-i18n.global.js"></script>
<script src="https://cdn.jsdelivr.net/npm/vue-router@4.1.6/dist/vue-router.global.js"></script>
<script src="https://cdn.jsdelivr.net/npm/element-plus@2.3.6/dist/index.full.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@element-plus/icons-vue@2.1.0/dist/index.iife.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/dayjs@1.11.7/dayjs.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/axios@1.4.0/dist/axios.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/echarts@5.4.3/dist/echarts.min.js"></script>

<script>
    // 全局配置
    window.__I18N__ = {
        locale: 'zh-CN',
        messages: {
            'zh-CN': {
                // 中文翻译
            },
            'en': {
                // 英文翻译
            }
        }
    };

    // 全局组件注册函数
    function getComponents() {
        return {};
    }

    // Axios配置
    const http = axios.create({
        baseURL: '/',
        timeout: 10000,
        headers: {
            'Content-Type': 'application/json'
        }
    });

    // 请求拦截器
    http.interceptors.request.use(
        config => {
            return config;
        },
        error => {
            return Promise.reject(error);
        }
    );

    // 响应拦截器
    http.interceptors.response.use(
        response => {
            if (response.data.code !== 200) {
                ElementPlus.ElMessage.error(response.data.message || '请求失败');
                return Promise.reject(new Error(response.data.message || '请求失败'));
            }
            return response.data.data;
        },
        error => {
            ElementPlus.ElMessage.error(error.message || '网络错误');
            return Promise.reject(error);
        }
    );
</script>
`
  );
  
  // 创建common-vue.html
  fs.writeFileSync(
    path.join(targetDir, 'views', 'common-vue.html'),
    `<view id="page.home"></view>

<script>
    var i18n = VueI18n.createI18n(Object.assign(window.__I18N__, {
        silentTranslationWarn: true,
        missingWarn: false,
        silentFallbackWarn: true,
        fallbackWarn: false
    }))
    var t = i18n.global.t

    const app = Vue.createApp({
        setup() {
            const elementEn = ElementPlusLocaleEn
            const elementZh = ElementPlusLocaleZhCn

            return {
                locale: window.__I18N__?.locale || 'en',
                elementEn,
                elementZh
            }
        }
    })

    app.use(ElementPlus)

    // 全局注册组件
    // Element Plus Icons
    for (const [key, component] of Object.entries(ElementPlusIconsVue)) {
        app.component('icon' + key, component)
    }
    for (const [key, component] of Object.entries(getComponents())) {
        app.component(key, component)
    }

    app.config.globalProperties.t = t
    app.config.globalProperties.$debug = (i, ...args) => {
        console.debug('VUE-DEUBG>>>', i, args.length ? args : '')
        return i
    }

    // 全局方法
    var { ElMessage, ElMessageBox, ElConfigProvider } = ElementPlus
</script>
<view id="common_routes"></view>
<script>
    // router
    const { createWebHashHistory, createRouter, useRouter, useRoute } = VueRouter
    var router = createRouter({
        history: createWebHashHistory(),
        routes
    })
    app.use(router)
    app.mount("#app")
</script>
`
  );
  
  // 创建common_routes.html
  fs.writeFileSync(
    path.join(targetDir, 'views', 'common_routes.html'),
    `<script>
  var routes = [
    {
      path: '/',
      redirect: '/home'
    },
    {
      path: '/home',
      component: app._context.components['page-home']
    }
  ]
</script>
`
  );
  
  // 创建主页
  fs.writeFileSync(
    path.join(targetDir, 'views', 'page.home.html'),
    `<template id="page-home">
  <div class="container mx-auto p-6">
    <h1 class="text-3xl font-bold mb-6">欢迎使用Kooboo</h1>
    <p class="mb-4">这是一个基本的Kooboo项目模板。</p>
    <p>开始构建你的应用吧！</p>
  </div>
</template>

<script>
  defineComponent('page-home', {
    template: '#page-home',
    setup() {
      return {};
    }
  });
</script>
`
  );
  
  // 创建主布局
  fs.writeFileSync(
    path.join(targetDir, 'layouts', 'main.html'),
    `<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kooboo项目</title>
    <view id="common"></view>
</head>
<body>
    <div class="hidden" k-placeholder="Main">Sample text inside the layout..</div>
    
    <div id="app">
        <page-component></page-component>
    </div>
    
    <view id="common-vue"></view>
</body>
</html>
`
  );
  
  // 创建主页面
  fs.writeFileSync(
    path.join(targetDir, 'pages', 'home.html'),
    `<layout name="main">
    <placeholder name="Main">
        <view id="page.home"></view>
    </placeholder>
</layout>
`
  );
} 