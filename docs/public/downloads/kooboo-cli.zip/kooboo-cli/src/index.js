#!/usr/bin/env node

import { Command } from 'commander';
import chalk from 'chalk';
import inquirer from 'inquirer';
import ora from 'ora';
import fs from 'fs-extra';
import path from 'path';
import { fileURLToPath } from 'url';
import { createProject } from './commands/create.js';

// 获取当前文件的目录
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// 获取package.json中的版本号
const packageJson = fs.readJsonSync(path.resolve(__dirname, '../package.json'));

// 创建命令行程序
const program = new Command();

// 设置版本号和描述
program
  .name('kooboo')
  .description('Kooboo项目脚手架工具')
  .version(packageJson.version);

// 创建项目命令
program
  .command('create')
  .description('创建一个新的Kooboo项目')
  .option('--name <name>', '项目名称')
  .option('--template <template>', '项目模板 (vue, react, default)')
  .action(async (options) => {
    try {
      // 如果没有提供项目名称，则提示用户输入
      if (!options.name) {
        const answers = await inquirer.prompt([
          {
            type: 'input',
            name: 'name',
            message: '请输入项目名称:',
            default: 'kooboo-project',
            validate: (input) => {
              if (/^([A-Za-z\-_\d])+$/.test(input)) return true;
              return '项目名称只能包含字母、数字、横线和下划线';
            }
          }
        ]);
        options.name = answers.name;
      }

      // 如果没有提供模板，则提示用户选择
      if (!options.template) {
        const answers = await inquirer.prompt([
          {
            type: 'list',
            name: 'template',
            message: '请选择项目模板:',
            choices: [
              { name: 'Vue-admin 后台模板', value: 'vue-admin-template' },
              // { name: 'React模板', value: 'react' },
              { name: '默认模板', value: 'default' }
            ],
            default: 'vue-admin-template'
          }
        ]);
        options.template = answers.template;
      }

      // 创建项目
      await createProject(options.name, options.template);
      
      console.log(chalk.green('\n✨ 项目创建成功！'));
      console.log(`\n  cd ${options.name}`);
      console.log('  开始开发你的Kooboo项目吧！\n');
    } catch (error) {
      console.error(chalk.red('创建项目失败:'), error);
      process.exit(1);
    }
  });

// 解析命令行参数
program.parse(process.argv); 