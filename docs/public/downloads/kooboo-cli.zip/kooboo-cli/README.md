# Kooboo CLI

一个命令行工具，用于快速创建符合Kooboo规范的项目结构。

## 安装

```bash
# 全局安装
npm install -g kooboo-cli

# 或者使用yarn
yarn global add kooboo-cli
```

## 使用方法

### 创建新项目

```bash
# 基本用法
kooboo create

# 指定项目名称
kooboo create --name my-kooboo-project

# 指定模板
kooboo create --template vue
```

### 可用模板

- `vue-admin-template` - Vue 3 + Element Plus模板
- `socket-tempalte` - sock 模板
- `default` - 基本模板

## 项目结构

使用Kooboo CLI创建的项目将包含以下目录结构：

```
project-name/
├── views/           # 视图文件
├── pages/           # 页面文件
├── layouts/         # 布局文件
├── scripts/         # JavaScript脚本
├── styles/          # CSS样式
├── apis/            # API定义
├── codeBlocks/      # 代码块
└── utils/       # 同步工具
```

## 开发

```bash
# 克隆仓库
git clone https://github.com/yourusername/kooboo-cli.git

# 安装依赖
cd kooboo-cli
npm install

# 链接到全局
npm link

# 取消链接
npm unlink kooboo-cli
```

## 许可证

MIT 